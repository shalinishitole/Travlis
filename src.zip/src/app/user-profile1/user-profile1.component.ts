import { Component } from '@angular/core';

@Component({
  selector: 'app-user-profile1',
  templateUrl: './user-profile1.component.html',
  styleUrls: ['./user-profile1.component.scss']
})
export class UserProfile1Component {

}
