export const GlobalVariable = Object({



    SERVICE_API_URL:        'http://localhost:58029/api/',
    BASE_API_URL:        'http://localhost:58029/',

    //===============================================================


  //   SERVICE_API_URL:        'https://www.api.travlisinc.com/api/',
  // BASE_API_URL:        'https://www.api.travlisinc.com/',


    //=======================================================
  //   SERVICE_API_URL:        'https://apitravlis.prismplusts.com/api/',
  // BASE_API_URL:        'https://apitravlis.prismplusts.com/',
      });
      //apitravlis.prismplusts.com/
