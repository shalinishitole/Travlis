import { Component } from '@angular/core';

@Component({
  selector: 'app-user-profile-hotel',
  templateUrl: './user-profile-hotel.component.html',
  styleUrls: ['./user-profile-hotel.component.scss']
})
export class UserProfileHotelComponent {

}
