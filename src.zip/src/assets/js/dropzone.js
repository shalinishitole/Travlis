(function($) {
  'use strict';
  $("my-awesome-dropzone").dropzone({
    url: "bootstrapdash.com/"
  });
})(jQuery);